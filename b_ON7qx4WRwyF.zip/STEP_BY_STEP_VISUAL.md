# 📸 Step-by-Step Visual Setup Guide

## Phase 1: MongoDB Atlas Setup (Copy-Paste Ready)

### Step 1: Open MongoDB Atlas
```
URL: https://www.mongodb.com/cloud/atlas/register
↓
Sign up with email
↓
Verify email (check inbox)
```

### Step 2: Create Cluster
```
Your Dashboard
    ↓
[Build a Database] button
    ↓
Choose FREE tier
    ↓
Select Region (closest to you)
    ↓
[Create Cluster] button
    ↓
⏳ Wait 3-5 minutes...
```

### Step 3: Create Database User
```
In MongoDB Dashboard:
    ↓
Left Menu → Security → Database Users
    ↓
[Add New Database User] button
    ↓
Username: expense_tracker_user
Password: YourPassword123 (write it down!)
    ↓
[Create User] button
```

### Step 4: Allow Connection
```
In MongoDB Dashboard:
    ↓
Left Menu → Security → Network Access
    ↓
[Add IP Address] button
    ↓
[Allow Access from Anywhere] button
    ↓
[Confirm] button
```

### Step 5: Get Connection String
```
Left Menu → Databases
    ↓
Your Cluster
    ↓
[Connect] button
    ↓
[Connect to Application]
    ↓
Language: Node.js
Version: 4.0 or later
    ↓
COPY this string:
mongodb+srv://expense_tracker_user:YourPassword123@cluster...
```

---

## Phase 2: Local Setup (Files Configuration)

### Step 6: Update .env.local File
```
File: .env.local (in project root)

BEFORE:
MONGODB_URI=mongodb+srv://your_username:your_password@your_cluster.mongodb.net/...

AFTER:
MONGODB_URI=mongodb+srv://expense_tracker_user:YourPassword123@cluster0.xxxxx.mongodb.net/expense_tracker?retryWrites=true&w=majority

Change:
- YourPassword123 → Your actual password from Step 3
- cluster0.xxxxx → Your actual cluster URL from Step 5
```

---

## Phase 3: Run The App

### Step 7: Start Development Server
```bash
# In your project directory:
pnpm dev

# You'll see:
✓ Compiled successfully
- Ready on http://localhost:3000
```

### Step 8: Open Browser
```
Open: http://localhost:3000

You'll see:
┌─────────────────────────────────┐
│     Student Expense Tracker     │
│  Manage Your Money Wisely       │
│                                 │
│  Email: [_________________]    │
│  Password: [________________]  │
│  [Login] button                 │
│                                 │
│  Demo: Use any email/password   │
└─────────────────────────────────┘
```

---

## Phase 4: Test The App

### Step 9: Create Account
```
Email:    test@example.com
Password: password123

Click [Login] button
```

### Step 10: After Login
```
You'll see the Dashboard:

┌─────────────────────────────────┐
│   💰 Student Expense Tracker    │
│ ▼ All Time                      │
│                                 │
│  💳 Total Cost:     0.00 ৳      │
│  💰 Total Income:   0.00 ৳      │
│  ✓ Remaining:       0.00 ৳      │
│                                 │
│  [+ Add Expense] [+ Add Income] │
│                                 │
│  Recent Transactions (empty)    │
└─────────────────────────────────┘
```

### Step 11: Add Your First Expense
```
Click: [+ Add Expense]

A modal appears:
┌─────────────────────────────────┐
│     Add Expense                 │
│                                 │
│  Date: [Today's Date]          │
│  Category: [Food ▼]            │
│  Description: [Groceries____]  │
│  Amount: [500.00___]           │
│                                 │
│  [Add Transaction] button       │
└─────────────────────────────────┘

Enter:
- Date: 15/01/2024
- Category: Food
- Description: Lunch
- Amount: 500

Click [Add Transaction]
```

### Step 12: Data Appears
```
You'll see:
✓ Transaction added successfully!

Dashboard updates:
┌─────────────────────────────────┐
│  💳 Total Cost:     500.00 ৳    │
│  💰 Total Income:   0.00 ৳      │
│  ✓ Remaining:      -500.00 ৳    │
│                                 │
│  Recent Transactions:           │
│  ┌─────────────────────────────┐│
│  │ 15/01 | Expense | Food     ││
│  │ Lunch | 500.00 ৳ | Delete ││
│  └─────────────────────────────┘│
└─────────────────────────────────┘
```

### Step 13: The Magic Test! ✨
```
Click: [Logout] button
↓
You see login screen again
↓
Login again:
Email: test@example.com
Password: password123
↓
Click [Login]
↓
YOUR DATA IS STILL THERE! 🎉
Total Cost: 500.00 ৳ (not gone!)
Transaction visible!
↓
This proves MongoDB is working!
```

---

## Phase 5: Add More Data

### Step 14: Add Income
```
Click: [+ Add Income]

Modal appears, enter:
- Date: 17/01/2024
- Category: Part-time Job (this is income)
- Description: Monthly salary
- Amount: 5000

Click [Add Transaction]
```

### Step 15: Check Dashboard
```
Dashboard now shows:
- Total Cost: 500.00 ৳
- Total Income: 5000.00 ৳
- Remaining: 4500.00 ৳ ✓

Pie chart shows: Food (100%)
```

### Step 16: Set Budget
```
Click: [Budget] in sidebar
↓
Enter: 3000
↓
Click [Set Budget]
↓
Shows: Monthly Budget: ৳ 3000

Since you spent 500, you're at 16% of budget ✓
```

---

## ✅ Verification Checklist

After Step 13, you should see:

- [x] Can login
- [x] Can add expense
- [x] Dashboard shows total cost
- [x] Can add income
- [x] Dashboard shows total income
- [x] Can view transactions in table
- [x] Can logout
- [x] **Data persists after logout!** ⭐
- [x] Can login again
- [x] **Same data is visible!** ⭐⭐⭐

If all checked: **You're done! 🎉**

---

## 🆘 If Something Goes Wrong

### "Please add your MONGODB_URI to .env.local"
```
1. Check .env.local exists in project root
2. Check MONGODB_URI is set
3. Stop dev server: Ctrl+C
4. Start again: pnpm dev
```

### "Invalid email or password"
```
1. Make sure password in .env.local matches MongoDB
2. Try simple password: password123
3. Check email/password in MongoDB dashboard
```

### Data not showing
```
1. Open browser console: F12
2. Look for red error messages
3. Check Network tab (F12 → Network)
4. Look for failed API requests
```

### Connection timeout
```
1. Check MongoDB cluster is running (MongoDB dashboard)
2. Check IP is whitelisted (Network Access)
3. Check internet connection
4. Try restarting: Ctrl+C then pnpm dev
```

---

## 📊 Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│              YOUR BROWSER (Frontend)                 │
│  ┌─────────────────────────────────────────────┐   │
│  │  Login Form → Create Account → Dashboard    │   │
│  │                                              │   │
│  │  Add Expense → Add Income → View Report    │   │
│  └─────────────────────────────────────────────┘   │
└──────────────────┬──────────────────────────────────┘
                   │ 
        (API Calls with JWT Token)
                   │
        ┌──────────▼──────────┐
        │   YOUR SERVER       │
        │  (Next.js API)      │
        │                     │
        │ /api/auth          │ (Login/Signup)
        │ /api/transactions  │ (Add/Delete Expense)
        │ /api/budget        │ (Set/Get Budget)
        └──────────┬──────────┘
                   │
        (MongoDB Driver)
                   │
        ┌──────────▼──────────┐
        │   MONGODB ATLAS     │
        │   (Cloud Database)  │
        │                     │
        │ users collection    │
        │ transactions col.   │
        │ budgets collection  │
        └─────────────────────┘

Your data is SAFE in MongoDB!
Not lost when you logout!
```

---

## 🎓 What's Happening Behind The Scenes

### When You Login:
```
1. Enter email & password
2. Sent to → /api/auth
3. API checks MongoDB for user
4. Password compared (encrypted)
5. If correct → JWT token created
6. Token stored in browser
7. Token used for all future requests
```

### When You Add Expense:
```
1. Click "Add Expense"
2. Enter details & click submit
3. Sent to → /api/transactions
4. Your JWT token sent with request
5. API verifies token ✓
6. Data saved to MongoDB
7. Linked to your User ID
8. Dashboard refreshes
```

### When You Logout & Login Again:
```
1. Click Logout
2. Token deleted from browser
3. Click Login again
4. New token created
5. API fetches transactions by User ID
6. All your data appears!
```

---

## 💾 Where Your Data Lives

```
MongoDB Cloud (MongoDB Atlas)
    │
    ├── users
    │   └── {email, encrypted_password, name}
    │
    ├── transactions
    │   └── {user_id, date, category, amount, type}
    │
    └── budgets
        └── {user_id, amount}

Your data is:
✓ Encrypted (passwords)
✓ Secure (only accessible by you)
✓ Persistent (never deleted)
✓ Backed up automatically
✓ Accessible from anywhere
```

---

## 🚀 You're All Set!

Once you've completed all steps:

1. ✅ Your app is running locally
2. ✅ Connected to MongoDB
3. ✅ User data is persisting
4. ✅ Ready for production

**Next steps:**
- Deploy to Vercel
- Share with friends
- Add more features
- Celebrate! 🎉

---

**For more details:** See `QUICK_START.md` or `SETUP_INSTRUCTIONS.md`
