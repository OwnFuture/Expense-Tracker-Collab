# MongoDB Setup Guide for Student Expense Tracker

Follow these steps carefully to set up MongoDB for your Student Expense Tracker application.

## Step 1: Create a MongoDB Account (If you don't have one)

1. Go to [MongoDB Cloud Atlas](https://www.mongodb.com/cloud/atlas/register)
2. Sign up with your email or use an existing account
3. Verify your email address

## Step 2: Create a Free Cluster

1. After logging in, click **"Create"** to create a new project (or use the default project)
2. Click **"Build a Database"**
3. Choose the **FREE** plan (M0 cluster is free forever)
4. Select your preferred region (closest to you is best)
5. Click **"Create Cluster"**
6. Wait 3-5 minutes for the cluster to be created

## Step 3: Create a Database User

1. Once your cluster is ready, click **"Security"** in the left menu → **"Quick Start"**
2. Create a **Database User**:
   - Username: `expense_tracker_user` (you can use any name)
   - Password: Create a strong password (save this!)
   - Click **"Create User"**

## Step 4: Add IP Whitelist

1. Still in Security, go to **"Network Access"**
2. Click **"Add IP Address"**
3. Click **"Allow Access from Anywhere"** (for development)
   - (In production, add specific IPs)
4. Click **"Confirm"**

## Step 5: Get Your Connection String

1. Go back to **"Databases"** and click your cluster
2. Click **"Connect"**
3. Choose **"Connect to Application"**
4. Select **"Node.js"** and version **"4.0 or later"**
5. Copy the connection string (it looks like):
   ```
   mongodb+srv://username:password@cluster.mongodb.net/expense_tracker?retryWrites=true&w=majority
   ```

## Step 6: Update Your .env.local File

1. Open `.env.local` in your project root
2. Replace the `MONGODB_URI` with your connection string:
   ```
   MONGODB_URI=mongodb+srv://expense_tracker_user:YOUR_PASSWORD@cluster.mongodb.net/expense_tracker?retryWrites=true&w=majority
   ```
3. Change `YOUR_PASSWORD` to the password you created in Step 3
4. Change `JWT_SECRET` to a random string for security:
   ```
   JWT_SECRET=your-very-secret-random-string-here-123456789
   ```

## Step 7: Test the Connection

1. Start your development server:
   ```
   pnpm dev
   ```

2. Open your app in the browser (usually http://localhost:3000)

3. Try to create a new account:
   - Email: `test@example.com`
   - Password: `password123`

4. If you see "Signup successful", your MongoDB is connected! ✅

## Step 8: Add Your First Transaction

1. Log in with the account you just created
2. Click **"+ Add Expense"** or **"+ Add Income"**
3. Add some transactions
4. Log out and log back in
5. **Your data will still be there!** ✅

## Troubleshooting

### "Please add your MONGODB_URI to .env.local"
- Make sure `.env.local` exists in your project root
- Restart your dev server after adding the URI
- Use `pnpm dev` to restart

### "Invalid email or password" during signup
- Make sure your password meets MongoDB's requirements
- Try a simpler password for testing

### Connection timeout
- Check if your IP address is whitelisted in MongoDB
- Verify your connection string has the correct password
- Make sure your cluster is running (check MongoDB dashboard)

### Data not persisting
- Verify you're using the same email/password to log in
- Check the browser console (F12) for any errors
- Make sure the token is being sent in API requests

## Database Structure

Your MongoDB will automatically create:

### Collections:
1. **users** - Stores user accounts with hashed passwords
2. **transactions** - Stores all expenses and income
3. **budgets** - Stores budget information per user

You don't need to create these manually - they're created automatically!

## Security Notes

1. **Never** commit `.env.local` to GitHub
2. Change `JWT_SECRET` to a random string in production
3. For production, use:
   - Strong passwords
   - IP whitelisting (only your server's IP)
   - Enable 2-factor authentication on MongoDB

## Next Steps

1. ✅ Data now persists in MongoDB
2. ✅ User authentication is secure with password hashing
3. ✅ Each user only sees their own data
4. You can now deploy to Vercel!

## Deploying to Vercel

1. Connect your GitHub repo to Vercel
2. Add environment variables in Vercel project settings:
   - `MONGODB_URI` (from Step 5)
   - `JWT_SECRET` (from your local .env.local)
3. Deploy!

For more info, visit:
- [MongoDB Atlas Documentation](https://www.mongodb.com/docs/atlas/)
- [Vercel Environment Variables](https://vercel.com/docs/projects/environment-variables)
