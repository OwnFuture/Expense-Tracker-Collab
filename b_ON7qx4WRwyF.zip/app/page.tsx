import { readFile } from 'fs/promises';
import path from 'path';

export default async function Home() {
  // Read the HTML file
  const htmlPath = path.join(process.cwd(), 'app', 'page.html');
  const html = await readFile(htmlPath, 'utf-8');

  return (
    <div dangerouslySetInnerHTML={{ __html: html }} />
  );
}
