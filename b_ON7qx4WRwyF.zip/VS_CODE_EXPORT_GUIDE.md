# 📥 Export to VS Code & Local Setup Guide

Complete step-by-step guide to export your expense tracker from v0 to VS Code and run it locally.

---

## 🎯 What You'll Do

1. Export the code from v0.app as ZIP
2. Extract the ZIP on your computer
3. Open in VS Code
4. Install dependencies
5. Run the dev server
6. Open preview in browser
7. Follow START_HERE.md

**Total Time: 15-20 minutes**

---

## STEP 1: Download the Code from v0 (2-3 minutes)

### Option A: Using the v0 UI (Recommended)

1. **In v0.app** - Look at the top-right corner
   - You'll see a menu (three dots `...` or arrow)
   
2. **Click the menu** → Select **"Download ZIP"**
   - This downloads your entire project

3. **Save the ZIP file**
   - Choose a location you remember (Desktop or Documents)
   - File will be named something like: `v0-project-XXXXX.zip`

### Option B: Via GitHub (If Connected)

If your v0 project is connected to GitHub:
1. Go to your GitHub repository
2. Click **Code** → **Download ZIP**
3. Save to your computer

### Option C: Using Terminal (Advanced)

If you have Git installed:
```bash
git clone <your-github-repo-url>
cd <your-project-folder>
```

---

## STEP 2: Extract the ZIP File (1 minute)

### Windows
1. Right-click the ZIP file
2. Select **Extract All...**
3. Choose where to extract (Desktop or a `Projects` folder)
4. Remember the folder path!

### Mac
1. Double-click the ZIP file
2. It automatically extracts
3. A new folder appears

### Linux
```bash
unzip v0-project-XXXXX.zip
cd v0-project
```

**Result:** A folder named `v0-project` or similar

---

## STEP 3: Open in VS Code (2 minutes)

### Option A: Drag & Drop

1. **Open VS Code**
2. **Drag** the extracted folder into VS Code window
3. It will open as a project

### Option B: File Menu

1. **Open VS Code**
2. **File** → **Open Folder**
3. Navigate to your extracted folder
4. Select it and click **Open**

### Option C: Command Line

```bash
cd path/to/your/extracted/folder
code .
```

**Result:** VS Code opens with all your files visible in the left sidebar

---

## STEP 4: Trust the Project (30 seconds)

When you open, VS Code might ask: **"Do you trust the authors?..."**

- Click **Yes, I trust the authors** ✓
- This allows VS Code to run scripts

---

## STEP 5: Install Node Dependencies (3-5 minutes)

### What Are Dependencies?

The project uses external libraries (MongoDB driver, JWT, bcrypt, etc). You need to install them.

### Installation Steps

#### Option A: Using VS Code Terminal (Easiest)

1. **Open Terminal in VS Code**
   - **Ctrl + `** (backtick) on Windows/Linux
   - **Cmd + `** on Mac
   - OR: **Terminal** → **New Terminal**

2. **You'll see a terminal panel at the bottom**

3. **Run this command:**
   ```bash
   pnpm install
   ```
   
   OR if pnpm not installed:
   ```bash
   npm install
   ```

4. **Wait for completion**
   - You'll see: `added XXX packages in X seconds` ✓

#### Option B: Using Command Prompt

1. **Open Command Prompt / Terminal**
2. Navigate to your project:
   ```bash
   cd C:\path\to\your\v0-project
   ```
   (Windows) or
   ```bash
   cd /path/to/your/v0-project
   ```
   (Mac/Linux)

3. Run:
   ```bash
   pnpm install
   ```

#### Option C: If pnpm Not Installed

Install pnpm first:
```bash
npm install -g pnpm
```

Then:
```bash
pnpm install
```

**What happens:**
- A `node_modules` folder is created (large!)
- All dependencies are downloaded
- Takes 3-5 minutes

---

## STEP 6: Start the Development Server (1 minute)

### In VS Code Terminal

```bash
pnpm dev
```

OR

```bash
npm run dev
```

### What You'll See

```
> v0-project@1.0.0 dev
> next dev

  ▲ Next.js 16.0.0
  - Local:        http://localhost:3000
  - Environments: .env.local

✓ Ready in 2.5s
✓ Compiled successfully
```

**Important:** Don't close this terminal! Keep it running.

---

## STEP 7: Open Preview in Browser (30 seconds)

### Option A: Click the Link

In the terminal output, you'll see:
```
  - Local:        http://localhost:3000
```

**Ctrl + Click** (or Cmd + Click on Mac) the link
- Browser opens automatically at `http://localhost:3000` ✓

### Option B: Manual

1. Open any browser (Chrome, Firefox, Edge, Safari)
2. Go to: `http://localhost:3000`
3. Your app appears! 🎉

### What You'll See

- Your Student Expense Tracker interface
- **Login/Signup section** (because you're not logged in yet)

---

## STEP 8: Verify Everything Works

### Testing the Frontend

1. **Create a test account** (with fake data, it won't save yet)
   - Email: `test@example.com`
   - Password: `password123`
   
2. You'll see the dashboard appear

3. **Go back to VS Code**

### You Should See in Terminal

```
✓ Compiled successfully
GET /api/auth 200 in 150ms
```

This means the API call worked! ✓

---

## ⚠️ Important Notes About MongoDB

### Right Now (Without MongoDB)

- **✓ UI loads** - You can see the app
- **✓ API calls work** - Errors are handled
- **✗ Data doesn't save** - Because MongoDB isn't connected yet

This is **NORMAL!** We fix it in the next step.

### Error You Might See

In browser console (F12 → Console tab):
```
Error: MongoClient is not connected
```

**DON'T PANIC!** This is expected. Follow START_HERE.md next to set up MongoDB.

---

## STEP 9: Now Follow START_HERE.md

In your VS Code, open:
- **File Explorer** (left sidebar)
- Expand the project
- Find and click: **START_HERE.md**

It opens in the editor. Now follow that checklist:

1. Create MongoDB account (free)
2. Create database
3. Update .env.local
4. Restart dev server (press Ctrl+C, then `pnpm dev`)
5. Test with real data persistence

---

## 🔧 Troubleshooting

### Problem: pnpm command not found

**Solution:**
```bash
npm install -g pnpm
```

Then try again:
```bash
pnpm install
```

### Problem: Port 3000 already in use

**Solution 1 - Find what's using it:**

Windows:
```bash
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

Mac/Linux:
```bash
lsof -i :3000
kill -9 <PID>
```

**Solution 2 - Use different port:**
```bash
pnpm dev -p 3001
```

Then go to: `http://localhost:3001`

### Problem: Can't see the app in browser

1. Check terminal - does it say "Ready in X seconds"?
2. Check browser URL - is it `http://localhost:3000`?
3. Try hard refresh: **Ctrl+Shift+R** (or **Cmd+Shift+R** on Mac)
4. Check VS Code terminal for errors (red text)

### Problem: "Cannot find module" error

**Solution:**
```bash
pnpm install
```

Run install again - sometimes packages don't download fully.

### Problem: .env.local file not found

**Solution:**
1. In VS Code, right-click the project root folder
2. Select **New File**
3. Name it: `.env.local`
4. Add your MongoDB URI:
   ```
   MONGODB_URI=your_connection_string_here
   JWT_SECRET=your_secret_key_here
   ```

---

## 📁 Project Structure (What You'll See in VS Code)

```
v0-project/
├── app/
│   ├── api/
│   │   ├── auth/
│   │   │   └── route.js          (Login/Signup API)
│   │   ├── transactions/
│   │   │   └── route.js          (Expenses API)
│   │   └── budget/
│   │       └── route.js          (Budget API)
│   ├── layout.tsx                (Root layout)
│   ├── page.tsx                  (Home page)
│   └── page.html                 (HTML file)
├── lib/
│   └── mongodb.js                (Database connection)
├── public/
│   ├── script.js                 (Frontend JavaScript)
│   ├── style.css                 (Styling)
│   └── ... other assets
├── .env.local                    (Your secrets - NOT in version control)
├── package.json                  (Dependencies list)
├── pnpm-lock.yaml               (Lock file)
├── START_HERE.md                (Setup checklist - FOLLOW THIS)
├── QUICK_START.md               (5-min setup)
├── README.md                    (Project overview)
└── ... other docs
```

---

## ✅ Checklist: You're Ready When...

- [ ] You downloaded the ZIP from v0.app
- [ ] You extracted it on your computer
- [ ] You opened the folder in VS Code
- [ ] You ran `pnpm install` (finished successfully)
- [ ] You ran `pnpm dev` (dev server running)
- [ ] Browser shows your app at `http://localhost:3000`
- [ ] You see the login page/dashboard
- [ ] Terminal shows `✓ Compiled successfully`

**If all checkmarks are done:** You're ready to follow START_HERE.md! ✓

---

## 🚀 Next Steps

1. **Close/minimize the browser**
2. Keep the VS Code terminal running
3. **Open: START_HERE.md** in VS Code
4. Follow the MongoDB setup checklist (10-15 min)

---

## 💡 Pro Tips

### Tip 1: Edit Files While Server Runs

The dev server watches for file changes. Just edit and save:
- Changes appear instantly in browser (hot reload)
- No need to restart server

### Tip 2: View Console Errors

Press **F12** in browser → **Console** tab
- See what errors the app is hitting
- Helps debugging

### Tip 3: Keep Terminal Visible

Drag the terminal panel larger so you can see all messages.

### Tip 4: Multiple Terminals

You can open multiple terminals in VS Code:
- One for `pnpm dev`
- One for manual commands
- Right-click terminal → New Terminal

---

## ❓ Still Stuck?

Try these in order:

1. **Restart everything**
   - Close VS Code
   - Close browser
   - Open VS Code again
   - Run `pnpm dev` again
   - Go to `http://localhost:3000`

2. **Check Node installation**
   ```bash
   node --version
   npm --version
   ```
   Should show version numbers.

3. **Delete node_modules and reinstall**
   ```bash
   rm -rf node_modules pnpm-lock.yaml
   pnpm install
   ```

4. **Look at START_HERE.md** - it has troubleshooting too!

---

## 🎉 You're All Set!

Your project is now in VS Code and running locally!

**Next: Follow START_HERE.md for MongoDB setup**

Good luck! 🚀
