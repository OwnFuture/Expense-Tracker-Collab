# 📚 Student Expense Tracker - Complete Setup Instructions

Welcome! Your expense tracker now uses **MongoDB** to permanently store user accounts and transaction data. This guide will walk you through setup step-by-step.

---

## 🎯 What Changed?

**Before (Old Version):**
- Data was stored locally in browser
- Logging out = losing all data
- No user accounts

**After (New Version):** 
- ✅ Real user accounts with login/signup
- ✅ Data stored securely in MongoDB
- ✅ Data persists forever (even after logout)
- ✅ Each user only sees their own data
- ✅ Passwords are encrypted

---

## 📖 Setup Instructions

Choose one option below:

### 🟢 **OPTION 1: Quick Setup (5 minutes)**
👉 Follow: [`QUICK_START.md`](./QUICK_START.md)

### 🔵 **OPTION 2: Detailed Setup (10 minutes)**
👉 Follow: [`MONGODB_SETUP_GUIDE.md`](./MONGODB_SETUP_GUIDE.md)

---

## 🚀 After Setup - Using Your App

### First Time:
1. Open http://localhost:3000
2. Create a new account (any email/password)
3. Add some expenses/income
4. Check your data is showing

### Testing Data Persistence:
1. Log out (click Logout button)
2. Log in again with same email/password
3. **Your transactions are still there!** ✅

---

## 📁 Project Structure

```
your-project/
├── app/
│   ├── api/
│   │   ├── auth/route.js          ← User login/signup
│   │   ├── transactions/route.js  ← Add/delete expenses
│   │   └── budget/route.js        ← Budget management
│   ├── page.html                  ← HTML interface
│   └── page.tsx                   ← Main page component
├── lib/
│   └── mongodb.js                 ← Database connection
├── public/
│   ├── script.js                  ← Updated with API calls
│   └── style.css                  ← Styling
├── .env.local                     ← 🔑 Your MongoDB credentials (DON'T SHARE!)
├── QUICK_START.md                 ← Fast setup
├── MONGODB_SETUP_GUIDE.md        ← Detailed setup
└── package.json
```

---

## 🔑 Environment Variables (.env.local)

The `.env.local` file contains sensitive data:

```env
MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/...
JWT_SECRET=your-secret-key
```

**⚠️ Important:**
- Never share `.env.local`
- Never commit it to GitHub
- `.env.local` is already in `.gitignore`

---

## 🔧 How It Works

### User Registration/Login:
```
You enter email + password
         ↓
API checks MongoDB
         ↓
Password is encrypted with bcryptjs
         ↓
JWT token is created for session
         ↓
Token stored in browser's localStorage
```

### Adding a Transaction:
```
You click "Add Expense"
         ↓
Frontend sends data to API
         ↓
API checks your JWT token ✅
         ↓
Data is saved to MongoDB with your User ID
         ↓
Dashboard updates automatically
```

### Data Security:
- 🔐 Passwords are hashed (never stored plain text)
- 🔐 Each user only sees their own data
- 🔐 JWT tokens expire in 7 days
- 🔐 API validates all requests

---

## 📊 Database Collections

MongoDB creates these collections automatically:

### 1. **users**
```javascript
{
  _id: ObjectId(...),
  email: "student@example.com",
  password: "$2a$10$...", // encrypted
  name: "student",
  createdAt: 2024-01-15T10:30:00.000Z
}
```

### 2. **transactions**
```javascript
{
  _id: ObjectId(...),
  userId: ObjectId(...),      // links to user
  date: 2024-01-15T00:00:00,
  category: "Food",
  description: "Groceries",
  amount: 800,
  type: "Expense",
  createdAt: 2024-01-15T10:30:00.000Z
}
```

### 3. **budgets**
```javascript
{
  _id: ObjectId(...),
  userId: ObjectId(...),
  amount: 5000,
  updatedAt: 2024-01-15T10:30:00.000Z
}
```

---

## 🆘 Common Questions

### Q: Where is my data stored?
**A:** MongoDB servers in the cloud. Safe and backed up automatically.

### Q: What if I forget my password?
**A:** Create a new account. (Password reset not implemented yet, you can add it later)

### Q: Can I use the app offline?
**A:** Partially - you'll see cached data, but changes won't sync until online.

### Q: Can I delete my account?
**A:** Not implemented yet, but you can delete manually in MongoDB dashboard.

### Q: Is my data secure?
**A:** Yes! Passwords are hashed, each user sees only their data, and HTTPS encrypts data in transit.

### Q: Can I share this with friends?
**A:** Yes! They can create their own accounts and their data will be completely separate.

---

## 🐛 Troubleshooting

### Issue: "Please add your MONGODB_URI to .env.local"
**Solution:**
1. Check `.env.local` exists in project root
2. Verify `MONGODB_URI` is set correctly
3. Restart dev server: `pnpm dev`

### Issue: "Invalid email or password" when signing up
**Solution:**
- MongoDB password might not match `.env.local`
- Try a simpler password (no special characters)
- Check MongoDB dashboard for user creation

### Issue: Connection timeout
**Solution:**
1. Check if MongoDB cluster is running (MongoDB dashboard)
2. Verify IP whitelist includes your IP
3. Check internet connection

### Issue: Data not saving
**Solution:**
1. Open browser console (F12)
2. Look for red error messages
3. Check network tab (F12 → Network) for API errors
4. Verify token is in localStorage

### Issue: "Unauthorized" error
**Solution:**
- Token might have expired (clear localStorage, login again)
- JWT_SECRET changed (must be consistent)

---

## 📈 Next Steps

### Level 1: ✅ Basic Setup
- [x] MongoDB Atlas account
- [x] App running
- [x] Test login/signup
- [x] Add transactions

### Level 2: Optional Features
- [ ] Password reset functionality
- [ ] Email verification
- [ ] Transaction categories customization
- [ ] Export data to CSV
- [ ] Multiple budgets per month

### Level 3: Deployment
- [ ] Deploy to Vercel
- [ ] Set up GitHub Actions for CI/CD
- [ ] Add monitoring/logging
- [ ] Scale to more users

---

## 📚 Useful Resources

### MongoDB:
- [MongoDB Atlas Docs](https://www.mongodb.com/docs/atlas/)
- [MongoDB Node.js Driver](https://www.mongodb.com/docs/drivers/node/)

### Authentication:
- [bcryptjs Documentation](https://www.npmjs.com/package/bcryptjs)
- [JWT Introduction](https://jwt.io/introduction)

### Deployment:
- [Vercel Docs](https://vercel.com/docs)
- [Environment Variables on Vercel](https://vercel.com/docs/projects/environment-variables)

---

## 💬 Need Help?

1. **Check logs:** `pnpm dev` shows server errors
2. **Browser console:** F12 shows client errors
3. **MongoDB Dashboard:** Check if data is being created
4. **Read docs:** See `QUICK_START.md` or `MONGODB_SETUP_GUIDE.md`

---

## 🎉 You're All Set!

Your expense tracker is now a **real, production-ready application** with:
- ✅ User authentication
- ✅ Secure data storage
- ✅ Persistent data
- ✅ Multi-user support

**Start using it now:** http://localhost:3000

Happy tracking! 📊💰
