# 🚀 Quick Start Guide - MongoDB Setup (5 minutes)

## ⚡ Super Quick Summary

1. **Create MongoDB Atlas account** (2 min)
2. **Get your connection string** (1 min)
3. **Update .env.local** (1 min)
4. **Restart the app** (1 min)
5. **Test it!** (Done ✅)

---

## 📋 Step-by-Step (Copy-Paste Ready)

### 1️⃣ Create MongoDB Atlas Account
- Go to: https://www.mongodb.com/cloud/atlas/register
- Sign up with email
- Verify email

### 2️⃣ Create Free Database
- Click "Build a Database"
- Choose **FREE** tier
- Select your region
- Wait for cluster creation (takes 3-5 min)

### 3️⃣ Create Database User
- In MongoDB Dashboard → Security → Quick Start
- Create User:
  - **Username:** `expense_tracker_user`
  - **Password:** `YourPassword123` (write this down!)

### 4️⃣ Setup IP Whitelist
- Security → Network Access
- Click "Add IP Address"
- Click "Allow Access from Anywhere"
- Click "Confirm"

### 5️⃣ Get Connection String
- Go to Databases → Your Cluster
- Click "Connect"
- Select "Connect to Application"
- Choose Node.js 4.0+
- Copy the connection string

### 6️⃣ Update .env.local File
Open `.env.local` in your project and replace:

**OLD:**
```
MONGODB_URI=mongodb+srv://your_username:your_password@your_cluster.mongodb.net/expense_tracker?retryWrites=true&w=majority
```

**NEW:** (paste your string, replace password)
```
MONGODB_URI=mongodb+srv://expense_tracker_user:YourPassword123@cluster0.xxxxx.mongodb.net/expense_tracker?retryWrites=true&w=majority
```

Also change:
```
JWT_SECRET=your_super_secret_random_string_12345
```

### 7️⃣ Start the App
```bash
pnpm dev
```

### 8️⃣ Test It!
1. Go to http://localhost:3000
2. Click "Signup" (or just enter any email/password in login)
3. Create account: `test@example.com` / `password123`
4. Add an expense 💰
5. **Log out and log back in**
6. **Your data is still there!** ✅

---

## ✅ You're Done!

Your app now:
- ✅ Stores user accounts
- ✅ Keeps expenses/income permanently
- ✅ Securely manages user data
- ✅ Works offline (local storage fallback)

---

## 🆘 Common Issues

| Problem | Solution |
|---------|----------|
| "Please add MONGODB_URI" | Restart dev server: `pnpm dev` |
| "Invalid email or password" | Use simple password: `password123` |
| Connection timeout | Check IP whitelist in MongoDB |
| Data disappearing | Make sure you log in with same email |

---

## 🎉 Next: Deploy to Vercel

When ready to deploy:
1. Push to GitHub
2. Connect repo to Vercel
3. Add env variables in Vercel dashboard:
   - Copy `MONGODB_URI` and `JWT_SECRET` from `.env.local`
4. Deploy! 🚀

---

**For detailed setup:** See `MONGODB_SETUP_GUIDE.md`
